import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wenetwork/main.dart';

class signuppaageuptwo extends StatefulWidget {
  const signuppaageuptwo({Key? key}) : super(key: key);

  @override
  State<signuppaageuptwo> createState() => _signuppaageuptwoState();
}

class _signuppaageuptwoState extends State<signuppaageuptwo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          title:   Container(
            padding: EdgeInsets.only(right: 50,left:0.5),
            margin: EdgeInsets.only(left: 0.5),
            child:FlatButton(
              height: 20,
              minWidth: 20,
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
              },
              child:Image.asset("asset/image/wenetworklogoo.png",),

            ),
          ),

          automaticallyImplyLeading: false,
          actions: <Widget>[
            Padding(
                padding: EdgeInsets.only(left: 0.5,right:0.5),

                child:  IconButton(
                  icon: Image.asset("asset/image/home.png",height: 20,width: 80,),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
                  },
                )
            ),
            Padding(
                padding:EdgeInsets.only(left: 0.5,right:0.5),
                child:  IconButton(
                  icon: Image.asset("asset/image/user.png",height: 20,width: 80,),
                  onPressed: () {  },
                )
            ),
            Padding(
                padding: EdgeInsets.only(left: 0.5,right:0.5),

                child: IconButton(
                  icon: Image.asset("asset/image/align.png",height: 20,width: 80,),
                  onPressed: () {  },
                )
            ),
          ]
      ),
      body:Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(top:40,bottom: 40),


              child:Text.rich(TextSpan(
                text: 'Thanks for signing up.Welcome\nto our community. We are happy\nto have you an board.',style: TextStyle(fontSize: 24,color: Colors.green,fontWeight: FontWeight.bold),
              ),textAlign: TextAlign.center
                ,)
          ),
          Row(
            children: [
              Container(
                  margin: EdgeInsets.only(left: 10),
                  //padding: EdgeInsets.only(left:10,right: 10,top:10,bottom: 500),
                  child: FlatButton(
                    onPressed: () {
                      String ul= 'https://www.wenetwork.app/';
                      launch(ul);
                    },
                    color: Colors.lightBlue,
                    height: 50,
                    minWidth: 370.0,
                    child: Text('Explore the innovators',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
                  )

              ),
            ],
          ),



        ],

      ),
    );
  }
}
