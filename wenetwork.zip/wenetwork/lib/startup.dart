import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wenetwork/ApiServices.dart';
import 'package:wenetwork/companyinfo.dart';
import 'package:wenetwork/google_sign_in.dart';
import 'package:wenetwork/main.dart';
import 'package:wenetwork/signin.dart';
import 'package:wenetwork/signuppagetwo.dart';
import 'package:wenetwork/startuppage.dart';

class startup extends StatefulWidget {
  const startup({Key? key}) : super(key: key);

  @override
  State<startup> createState() => _startupState();
}

class _startupState extends State<startup> {
  bool _isObscure1 = true;

  final MyController = TextEditingController();
  final MyController2 =TextEditingController();
  final MyController3 =TextEditingController();
  final MyController4 =TextEditingController();



  callbusinessApi() {
    final service = ApiServices();

    service.apiCallLogin({
      "Email": MyController.text,
      "Password": MyController2.text,
      "FirstName": MyController3.text,
      "LastName": "",
      "UserRole": "1",
      "DeviceInfo": "",

    }).then((value) async {
      if (value.status!.StatusCode == 200) {
        SharedPreferences prefr = await SharedPreferences.getInstance();
        prefr.setString("UserToken", value.usertoken ?? "");
        prefr.setString("UserId", value.userId ?? "");
        prefr.setString("FirstName", value.firstName ?? "");
        prefr.setString("LastName", value.lastName ?? "");
        Navigator.push(
            context,MaterialPageRoute(builder: (context)=>companyinfo(campany: 'business',))
        );


        //  Navigator.push(context, MaterialPageRoute(builder: (context)=>investor(fromScreen: 'fromScreen')));
      } else {
        Fluttertoast.showToast(
            msg: "Something went wrong",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          title:   Container(
            padding: EdgeInsets.only(right: 50,left:0.5),
            margin: EdgeInsets.only(left: 0.5),
            child:FlatButton(
              height: 20,
              minWidth: 20,
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
              },
              child:Image.asset("asset/image/wenetworklogoo.png",),

            ),
          ),
          backgroundColor: Colors.black,

          automaticallyImplyLeading: false,
          actions: <Widget>[
            Padding(
              padding: EdgeInsets.only(left: 0.5,right:0.5),

              child: IconButton(
                icon: Image.asset("asset/image/home.png",height: 20,width: 80,),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
                },
              )
              ),
            Padding(
              padding:EdgeInsets.only(left: 0.5,right:0.5),
              child:IconButton(
                icon: Image.asset("asset/image/user.png",height: 20,width: 80,),
                onPressed: () {  },
              )
            ),
            Padding(
              padding: EdgeInsets.only(left: 0.5,right:0.5),

              child: IconButton(
                icon: Image.asset("asset/image/align.png",height: 20,width: 80,),
                onPressed: () {  },
              )
            ),
          ]
      ),
      body:SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                    child: IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(Icons.arrow_back_ios,color: Colors.grey,),
                    )

                ),
              ],

            ),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.only(left: 20,right:10),
                  child: Text('Business\'s Sign up',style: TextStyle(color: Colors.white,fontSize: 22,fontWeight: FontWeight.bold),),
                )

              ],

            ),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.only(left:10,top: 5,bottom: 2),
                  height: 50,
                  width: 50,
                  child:IconButton(
                    icon: Image.asset("asset/image/google.png",height: 40,width: 100,),
                    onPressed: () {
                     /* final provider =Provider.of<GoogleSignInProvider>(context,listen:false);
                      provider.googleLogin();*/
                    },
                  ),

                ),
                Container(
                  child: TextButton(
                    onPressed: () {
                      final provider =Provider.of<GoogleSignInProvider>(context,listen:false);
                      provider.googleLogin();

                    },
                    child: Text("Sign up using Google",style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),),

                  ),
                 // child: Center(child: Text('Sign up using Google',style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),)),
                )
              ],
            ),
            Row(
              children: [
                Container(
                    padding: EdgeInsets.only(left:10,top:5,bottom: 4),
                  height: 50,
                  width: 50,
                    child:IconButton(
                      icon: Image.asset("asset/image/facebook.png",height: 40,width: 100,),
                      onPressed: () {  },
                    )

                ),
                Container(
                  child: TextButton(
                    onPressed: () {

                    },
                    child: Text('Sign up using Facebook',style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),),

                  ),
                 // child: Text('Sign up using Facebook',style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),),
                )
              ],
            ),
            Row(
              children: [
                Expanded(
                    child: Container(
                      margin: const EdgeInsets.only(left: 10,right: 15),
                      child: Divider(
                        color: Colors.white38,
                        height: 50,
                      ),
                    )
                ),
                Text('OR',style:TextStyle(color: Colors.grey)),
                Expanded(
                    child: Container(
                      margin: const EdgeInsets.only(left: 10,right: 15),
                      child: Divider(
                        color: Colors.white38,
                        height: 50,
                      ),
                    )
                ),

              ],
            ),
            Column(
              children:[
                Container(

                  decoration: BoxDecoration(color:Colors.black),
                  child: Padding(
                      padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom:10),
                      child: Center(
                        child: TextFormField(
                          style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                          decoration: InputDecoration(
                            hintText: 'Enter email address',
                            hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white70),),
                            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                          ),
                          controller: MyController,
                        ),

                      )
                  ),
                ),
                Container(

                  // decoration: BoxDecoration(color:Colors.black),
                  child: Padding(
                      padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom:10),

                      child: Center(
                        child: TextFormField(
                          obscureText: _isObscure1,
                          style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                          decoration: InputDecoration(
                              hintText: 'Enter password',
                              hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(color: Colors.white70),),
                                enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                              suffixIcon: IconButton(

                                icon: Icon(_isObscure1?Icons.visibility_off:Icons.visibility,color: Colors.white,),
                                onPressed: (){
                                  setState(() {
                                    _isObscure1=!_isObscure1;
                                  });
                                },
                              )
                          ),
                          controller: MyController2,
                        ),

                      )
                  ),
                ),
                Container(

                  decoration: BoxDecoration(color:Colors.black),
                  child: Padding(
                      padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom:10),
                      child: Center(
                        child: Row(
                          children: [
                            Container(
                              child: SizedBox(
                                width:170,
                                child: TextFormField(
                                  style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                                  decoration: InputDecoration(
                                    hintText: 'First name',
                                    hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                                    focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(color: Colors.white70)),
                                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                                  ),
                                  controller: MyController3 ,
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(left: 20),
                              child: SizedBox(
                                width:170,
                                child: TextFormField(
                                  style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                                  decoration: InputDecoration(
                                    hintText: 'Last name',
                                    hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                                    focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(color: Colors.white70)),
                                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                                  ),
                                  controller: MyController4 ,
                                ),
                              ),
                            ),
                          ],
                        ),


                      )
                  ),),

              ],
            ),

            Center(
              child: Row(
                children: [
                  Container(
                      padding: EdgeInsets.only(left: 10,right: 5,top: 10,bottom:10),
                      child: FlatButton(
                        onPressed: () async {
                          SharedPreferences prefr = await SharedPreferences.getInstance();
                          String firstname = prefr.getString("FirstName")??"";
                          print(firstname);
                          callbusinessApi();



                          /*Navigator.push(
                              context,MaterialPageRoute(builder: (context)=>companyinfo(campany: 'business',))
                          );*/
                        },
                        color: Colors.green,
                        height: 50,
                        minWidth: 370.0,
                        child: Text('Proceed',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
                      )




                  ),
                ],
              ),
            ),
            Row(
              children: <Widget>[
                const Text('Already have an account?',style: TextStyle(color: Colors.white70),),
                TextButton(
                  child: const Text(
                    'Sign in',
                    style: TextStyle(fontSize: 15,color: Colors.deepOrange),
                  ),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>signin(signn: 'Business\'s',)));
                  },
                )
              ],
              mainAxisAlignment: MainAxisAlignment.center,
            ),

          ],
        ),
      ),
    );

  }
}
