
import 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wenetwork/ApiServices.dart';
import 'package:wenetwork/companyinfo.dart';
import 'package:wenetwork/google_sign_in.dart';
import 'package:wenetwork/signin.dart';
import 'package:wenetwork/signuppage.dart';
import 'package:wenetwork/signuppagetwo.dart';
import 'main.dart';

class investor extends StatefulWidget {

  String fromScreen;
  investor({
    required this.fromScreen
});

  @override
  State<investor> createState() => _investorState();
}

class _investorState extends State<investor> {

  bool _isLoggin=false;
  Map _userobj= {};










  bool _isObscure = true;

  final myController = TextEditingController();
  final myController2 =TextEditingController();
  final myController3 =TextEditingController();
  final myController4 =TextEditingController();

  callsignupApi(){
    final service= ApiServices();

    service.apiCallLogin({
      "Email": myController.text,
      "Password":myController2.text,
      "FirstName":myController3.text,
      "LastName":myController4.text,
      "UserRole":"1",
      "DeviceInfo":"",

    }).then((value) async {
      if(value.status!.StatusCode==200){
        SharedPreferences prefr= await SharedPreferences.getInstance();
        prefr.setString("UserToken",value.usertoken??"");
        prefr.setString("UserId",value.userId??"");
        prefr.setString("FirstName",value.firstName??"");
        prefr.setString("LastName", value.lastName??"");
        if(widget.fromScreen== "Investor\'s") {
          Navigator.push(
              context, MaterialPageRoute(
              builder: (context) =>
                  companyinfo(campany: 'investor',))
          );
        }else
        {
          Navigator.push(
              context, MaterialPageRoute(
            builder: (context) =>
                signuppaageuptwo(),));
        }




        //  Navigator.push(context, MaterialPageRoute(builder: (context)=>investor(fromScreen: 'fromScreen')));
      } else{
        Fluttertoast.showToast(
            msg: "Something went wrong",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
            title:   Container(
              padding: EdgeInsets.only(right: 50,left:0.5),
              margin: EdgeInsets.only(left: 0.5),
              child:FlatButton(
                height: 20,
                minWidth: 20,
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
                },
                child:Image.asset("asset/image/wenetworklogoo.png",),

              ),
            ),

            automaticallyImplyLeading: false,
            actions: <Widget>[
        Padding(
        padding: EdgeInsets.only(left: 0.5,right:0.5),

        child:  IconButton(
          icon: Image.asset("asset/image/home.png",height: 20,width: 80,),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
          },
        )
      ),
              Padding(
                padding:EdgeInsets.only(left: 0.5,right:0.5),
                child:  IconButton(
                  icon: Image.asset("asset/image/user.png",height: 20,width: 80,),
                  onPressed: () {  },
                )
              ),
              Padding(
                  padding: EdgeInsets.only(left: 0.5,right:0.5),

              child: IconButton(
                icon: Image.asset("asset/image/align.png",height: 20,width: 80,),
                onPressed: () {  },
              )
              ),
      ]
        ),
         body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                   children: [
                      Container(
                        child: IconButton(
                          onPressed: () {
                          Navigator.pop(context);
                        },
                          icon: Icon(Icons.arrow_back_ios,color: Colors.grey,),
                        )

                      ),
                    ],

                  ),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.only(left: 20,right:10),
                        child: Text(widget.fromScreen+' sign up',style: TextStyle(color: Colors.white,fontSize: 22,fontWeight: FontWeight.bold),),
                      )

                    ],

                  ),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.only(left:10,top: 5,bottom: 2),
                        height: 50,
                         width: 50,
                        child:  IconButton(
                            icon: Image.asset('asset/image/google.png'),
                            onPressed: () {  },
                          )

                      ),
                      Container(
                        child: TextButton(
                          onPressed: () {
                            final provider =Provider.of<GoogleSignInProvider>(context,listen:false);
                            provider.googleLogin();

                          },
                          child: Text("Sign up using Google",style: TextStyle(color:Colors.white70,fontWeight: FontWeight.bold),),

                        ),
                            //child: Center(child: Text('Sign up using Google',style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),)),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Container(
                        height: 35,
                        width: 50,
                          child:IconButton(
                            padding: EdgeInsets.only(left:10,top:8,bottom: 4),
                            icon: Image.asset("asset/image/facebook.png"),
                            onPressed: () {

                            },
                          )

                      ),
                      Container(
                        child: TextButton(
                          onPressed: () async{
                          FacebookAuth.instance.login(
                              permissions: ["public-profile","email"]
                          ).then((value) {
                            FacebookAuth.instance.getUserData().then((userData){
                              setState((){
                                _isLoggin=true;
                                _userobj=userData;
                              }
                              );
                            });
                          });
                        },
                        child:Text('Sign up using Facebook',style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),),

                        ),
                       // child: Center(child: Text('Sign up using Facebook',style: TextStyle(color: Colors.white70,fontWeight: FontWeight.bold),)),
                      ),

                    ],
                  ),
                  Row(
                    children: [
                      Expanded(
                          child: Container(
                            margin: const EdgeInsets.only(left: 10,right: 15),
                            child: Divider(
                              color: Colors.white38,
                              height: 50,
                            ),
                          )
                      ),
                      Text('OR',style:TextStyle(color: Colors.grey)),
                      Expanded(
                          child: Container(
                            margin: const EdgeInsets.only(left: 10,right: 15),
                            child: Divider(
                              color: Colors.white38,
                              height: 50,
                            ),
                          )
                      ),

                    ],
                  ),
                  Column(
                    children:[
                       Container(

                         decoration: BoxDecoration(color:Colors.black),
                        child: Padding(
                            padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom:10),
                           child: Center(
                             child: TextFormField(

                               style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                          decoration: InputDecoration(
                       hintText: 'Enter email address',
                            hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white70),),
                            enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                          ),
                         controller: myController,
                     ),

                   )
      ),
                       ),
                      Container(

                       // decoration: BoxDecoration(color:Colors.black),
                        child: Padding(
                            padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom:10),

                            child: Center(
                              child: TextFormField(
                                obscureText: _isObscure,
                                style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                                decoration: InputDecoration(
                                  hintText: 'Enter password',
                                  hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white70),),
                                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                                  suffixIcon: IconButton(

                                    icon: Icon(_isObscure?Icons.visibility_off:Icons.visibility,color: Colors.white,),
                                    onPressed: (){
                                      setState(() {
                                        _isObscure=!_isObscure;
                                      });
                                    },
                                  )
                                ),
                                controller: myController2,
                              ),

                            )
                        ),
                      ),
                          Container(

                            decoration: BoxDecoration(color:Colors.black),
                            child: Padding(
                                padding: EdgeInsets.only(left: 10,right: 10,top: 10,bottom:10),
                                child: Center(
                                  child: Row(
                                    children: [
                                      Container(
                                        child: SizedBox(
                                          width:170,
                                          child: TextFormField(
                                            style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                                            decoration: InputDecoration(
                                              hintText: 'First name',
                                              hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                                              focusedBorder: UnderlineInputBorder(
                                                borderSide: BorderSide(color: Colors.white70)),
                                              enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                                            ),
                                            controller: myController3,
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 20),
                                        child: SizedBox(
                                          width:170,
                                          child: TextFormField(
                                            style: TextStyle(color: Colors.grey),cursorColor: Colors.grey,
                                            decoration: InputDecoration(
                                              hintText: 'Last name',
                                              hintStyle: TextStyle(fontSize: 16.0, color: Colors.grey),
                                              focusedBorder: UnderlineInputBorder(
                                                  borderSide: BorderSide(color: Colors.white70)),
                                              enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70),),
                                            ),
                                            controller: myController4,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),


                                )
                            ),),




      ],
                  ),

                      Center(
                        child: Row(
                          children: [
                            Container(
                                padding: EdgeInsets.only(left: 10,right: 5,top: 10,bottom:10),
                                child: FlatButton(
                                  onPressed: () async {
                                    SharedPreferences prefr = await SharedPreferences.getInstance();
                                    String firstname = prefr.getString("FirstName")??"";
                                    print(firstname);
                                    callsignupApi();
                                  /*  if(widget.fromScreen== "Investor\'s") {
                                      Navigator.push(
                                          context, MaterialPageRoute(
                                          builder: (context) =>
                                              companyinfo(campany: 'investor',))

                                    }else
                                      {
                                        Navigator.push(
                                            context, MaterialPageRoute(
                                            builder: (context) =>
                                            signuppaageuptwo(),));
                                      }*/
                                  },
                                  color: Colors.green,
                                  height: 50,
                                  minWidth: 370.0,
                                  child: Text('Proceed',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
                                )




                            ),
                          ],
                        ),
                      ),
                  Row(
                    children: <Widget>[
                      const Text('Already have an account?',style: TextStyle(color: Colors.white70),),
                      TextButton(
                        child: const Text(
                          'Sign in',
                          style: TextStyle(fontSize: 15,color: Colors.deepOrange),
                        ),
                        onPressed: () {
                          if (widget.fromScreen == "Investor\'s") {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => signin(
                                  signn: 'Investor\'s',)));
                          }

                          else{
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => signin(
                                  signn: "Stakeholder\'s",)));

                          }
                        }
                      )
                    ],
                    mainAxisAlignment: MainAxisAlignment.center,
                  ),

                ],
            ),
         ),
        );


  }

}
