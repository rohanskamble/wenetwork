import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:wenetwork/inovationesg.dart';
import 'package:wenetwork/main.dart';

class loginpage extends StatefulWidget {


  String loginname;
  loginpage({
    required this.loginname
});

  @override
  State<loginpage> createState() => _loginpageState();
}

class _loginpageState extends State<loginpage> {


  String label="";

  getUser() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState((){
      label=preferences.getString("FirstName")??"";
    });

  }
  @override
  void initState() {
    getUser();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          title:   Container(
            padding: EdgeInsets.only(right: 50,left:0.5),
            margin: EdgeInsets.only(left: 0.5),
            child:FlatButton(
              height: 20,
              minWidth: 20,
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
              },
              child:Image.asset("asset/image/wenetworklogoo.png",),

            ),
          ),

          automaticallyImplyLeading: false,
          actions: <Widget>[
            Padding(
                padding: EdgeInsets.only(left: 0.5,right:0.5),

                child:  IconButton(
                  icon: Image.asset("asset/image/home.png",height: 20,width: 80,),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
                  },
                )
            ),
            Padding(
                padding:EdgeInsets.only(left: 0.5,right:0.5),
                child:  IconButton(
                  icon: Image.asset("asset/image/user.png",height: 20,width: 80,),
                  onPressed: () {  },
                )
            ),
            Padding(
                padding: EdgeInsets.only(left: 0.5,right:0.5),

                child: IconButton(
                  icon: Image.asset("asset/image/align.png",height: 20,width: 80,),
                  onPressed: () {  },
                )
            ),
          ]
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
              margin: EdgeInsets.only(top:40,bottom: 40),


              child:RichText(
                textAlign: TextAlign.center,
                text: TextSpan(

                  children: [
                  TextSpan(
                  text: 'Welcome ',style: TextStyle(fontSize: 24,color: Colors.green,fontWeight: FontWeight.bold),
                ),
                    TextSpan(
                      text: label,style: TextStyle(fontSize: 24,color: Colors.green,fontWeight: FontWeight.bold),
                    ),
                    TextSpan(
                      text: ', what would you like to do?'/*+widget.loginname*/,style: TextStyle(fontSize: 24,color: Colors.green,fontWeight: FontWeight.bold),
                    ),

                  ]
                )),
          ),
          Row(
            children: [
              Container(
                  margin: EdgeInsets.only(left: 10,bottom: 20),
                  //  padding: EdgeInsets.only(left:10,right: 10,top:10,bottom: 500),
                  child: FlatButton(
                    onPressed: () {
                      /*String ul= 'https://www.wenetwork.app/';
                                      launch(ul);*/
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>inovationesg(innovation: 'loginpage',)));
                    },
                    color: Colors.deepOrange,
                    height: 50,
                    minWidth: 370.0,
                    child: Text('Create a Subnetwork',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
                  )

              ),

            ],
          ),
          Row(
            children: [
              Container(
                  margin: EdgeInsets.only(left: 10),
                  //padding: EdgeInsets.only(left:10,right: 10,top:10,bottom: 500),
                  child: FlatButton(
                    onPressed: () {
                      String ul= 'https://www.wenetwork.app/';
                      launch(ul);
                    },
                    color: Colors.lightBlue,
                    height: 50,
                    minWidth: 370.0,
                    child: Text('Explore the innovators',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold),),
                  )

              ),
            ],
          ),



        ],

      ),
    );
  }
}
